function [binaryImage] = getBinaryImage(image, lowThreshold)

% Convert
imageGrayScale = rgb2gray(image);

% Find values depending on threshold
belowThreshold = (imageGrayScale < lowThreshold);
aboveThreshold = (imageGrayScale >= lowThreshold);

% Set to max or min value depending on threshold
imageGrayScale(belowThreshold) = 255;
imageGrayScale(aboveThreshold) = 0;

% Erode, dilate and binarize
structuringElement = offsetstrel('ball', 3, 3);
imageGrayScale = imerode(imageGrayScale, structuringElement);
imageGrayScale = imdilate(imageGrayScale, structuringElement);
binaryImage = imbinarize(double(imageGrayScale));

binaryImage = imclearborder(binaryImage);

end