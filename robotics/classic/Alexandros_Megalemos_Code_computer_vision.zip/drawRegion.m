function [] = drawRegion(property)

  boundingBox = property.BoundingBox;
  rectangle('position', [boundingBox(1), boundingBox(2), boundingBox(3), boundingBox(4)],...
  'edgeColor','green','lineWidth', 1 );

end