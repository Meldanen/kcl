function [] = analyseImage(properties, includeNumbering, includeAxes)

area = [properties.Area];
[~, indices] = sort(area, 'descend');

for i = 1 : length(properties)
  % Get the current property
  property = properties(i);
  
  % Draw its region
  drawRegion(property)

  % Number the region
  if includeNumbering
    numberRegion(properties(indices(i)), i, includeAxes)
  end
  
  % Draw the axis
  drawAxis(property)
  
end

end