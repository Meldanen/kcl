image = imread('image.png');

% Manually selected by trial and error
lowThreshold = 110;

% First get the binary image
binaryImage = getBinaryImage(image, lowThreshold);

% Show the image so that we can start drawing on it
imshow(image);

% Create the properties for the region
regionProperties = regionprops(binaryImage, 'boundingBox', 'area', 'centroid', 'orientation', 'majorAxisLength');

% Analyse the image
includeNumbering = true;
includeAxes = true;
analyseImage(regionProperties, includeNumbering, includeAxes)

% Save the image
saveas(gcf,'imageWithRegions', 'png')