function [] = drawAxis(property)

centroid = property.Centroid;
orientation = property.Orientation;
majorAxisLength = property.MajorAxisLength;
x = centroid(1) + [-1 1] * majorAxisLength * cosd(orientation) / 2;
y = centroid(2) - [-1 1] * majorAxisLength * sind(orientation) / 2;
line(x, y, 'color', 'red');

end