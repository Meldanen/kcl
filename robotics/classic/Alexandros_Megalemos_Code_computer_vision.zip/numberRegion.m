function [] = numberRegion(property, iteration, includesAxes)

% Small offset so that the number doesn't overlap with the axes
if includesAxes
    offset = 10;
else
    offset = 0;
end

centroid = property.Centroid;
centroid1 = centroid(1) + offset;
centroid2 = centroid(2) + offset;
text(centroid1, centroid2, sprintf('%d', iteration), ...
    'horizontalAlignment', 'center', ...
    'verticalAlignment', 'middle','color','green');

end