a1 = 1.5;
a2 = 1;
theta1 = -0.2;
theta2 = 0.5;
d3 = 1;
theta4 = 0.4;

jac = jacobian(a1,a2,theta1,theta2,d3);
