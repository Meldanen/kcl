function [] = plotMovement(theta1, theta2, d3, theta4, steps)

stepVector = (0:steps);

plot(stepVector, theta1(1:10:end), 'r--o');
plot(stepVector, theta2(1:10:end), 'b--o');
plot(stepVector, d3(1:10:end), 'g--o');
plot(stepVector, theta4(1:10:end), 'm--o');

legend('theta1', 'theta2', 'd3', 'theta4')
xlabel('Steps');
grid on;