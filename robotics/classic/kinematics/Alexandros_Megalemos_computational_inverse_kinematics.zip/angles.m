function [theta1, theta2, d3f, th4] = angles(x, y, z, f, a1, a2, d3, sign)
    
    cos3 = (x^2 + y^2 - a1^2 - a2^2) / (2*a1*a2);

    theta2 = atan2(sign * sqrt((1-cos3^2)),cos3);
        
    theta1 = atan2(y,x)-atan2(a2*sin(theta2), a1 + a2*cos3);
        
    d3f = d3-z;
    
    th4 = -f + theta1 + theta2;
end