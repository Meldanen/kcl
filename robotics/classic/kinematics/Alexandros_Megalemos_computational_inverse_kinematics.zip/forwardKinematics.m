function forwardKinematics = forwardKinematics(a1,a2,theta1,theta2,d3,theta4)

w1 = [0 0 1]';
w2 = [0 0 1]';
w3 = [0 0 0]'; %prismatic joint
v3 = [0 0 -1]';
w4 = [0 0 -1]';

q1 = [0 0 0]';
q2 = [a1 0 0]';
q4 = [a1+a2 0 0]';

xi1 = [-cross(w1, q1); w1];
xi2 = [-cross(w2, q2); w2];
xi3 = [v3; w3];
xi4 = [-cross(w4, q4); w4];

ex1 = expm(twist(xi1)*theta1);
ex2 = expm(twist(xi2)*theta2);
ex3 = expm(twist(xi3)*d3);
ex4 = expm(twist(xi4)*theta4);

translationg0 = [a1+a2 0 0]';
g0=[rotz(0)*roty(0)*rotx(180),translationg0 ; zeros(1,3),1];

productOfExponentials = ex1*ex2*ex3*ex4*g0;

forwardKinematics = productOfExponentials;

end