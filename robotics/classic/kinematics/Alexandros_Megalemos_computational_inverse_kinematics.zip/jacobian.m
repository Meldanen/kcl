function jacobian = jacobian(a1, a2, theta1, theta2, d3)

% Figure out the twists/screws
w1 = [0 0 1]';
w2 = [0 0 1]';
w3 = [0 0 0]'; %prismatic joint
v3 = [0 0 -1]';
w4 = [0 0 -1]';

q1 = [-a1-a2 0 0]';
q2 = [-a2 0 0]';
q4 = [0 0 0]';

xi1 = [-cross(w1, q1); w1];
xi2 = [-cross(w2, q2); w2];
xi3 = [v3; w3]; % for prismatic
xi4 = [-cross(w4, q4); w4];

ex1 = expm(twist(xi1)*theta1);
ex2 = expm(twist(xi2)*theta2);
ex3 = expm(twist(xi3)*d3);

% Create the adjoints
p1 = [ex1(1, 4); ex1(2, 4); ex1(3, 4)];
R1 = ex1(1:3, 1:3);
adjoint1 = [R1 skew(p1)*R1; zeros(3, 3) R1];

ex = ex1*ex2;
p2 = [ex(1, 4); ex(2, 4); ex(3, 4)];
R2 = ex(1:3, 1:3);
adjoint2 = [R2 skew(p2)*R2; zeros(3, 3) R2];

ex = ex1*ex2*ex3;
p3 = [ex(1, 4); ex(2, 4); ex(3, 4)];
R3 = ex(1:3, 1:3);
adjoint3 = [R3 skew(p3)*R3; zeros(3, 3) R3];

% Convert to current configuration
xi1_2 = xi1;
xi2_2 = adjoint1*xi2;
xi3_2 = adjoint2*xi3;
xi4_2 = adjoint3*xi4;

% Construct the jacobian
jacobian = ([xi1_2 xi2_2 xi3_2 xi4_2]);

end