function tw = twist(xi) % TWIST converts xi from a 6-vector to a 4x4 matrix % % tw = TWIST(xi) % % The form of xi is [v1; v2; v3; w1; w2; w3]
    tw(1:3, 1:3) = skew(xi(4:6));
    tw(1:3, 4) = xi(1:3); 
    tw(4, 1:4) = 0;
end