function [theta1d,theta2d,d3d,theta4d]=inverseKinematics(xd,yd,zd,f,a1,a2,theta1,theta2,d3,theta4)

% xd, yd, and zd is the destination

% Compute initial values before starting to converge
jac = jacobian(a1,a2,theta1,theta2,d3);
fKinematics = forwardKinematics(a1,a2,theta1,theta2,d3,theta4);
rotationOfForwardKinematics = fKinematics(1:3,1:3);
val = atan2(rotationOfForwardKinematics(2,1),rotationOfForwardKinematics(1,1));
dt = [1 1 1 1];

while (norm(dt)>=0.001)
    dx = [xd;yd;zd;0;0;round(f,5);]-[fKinematics(1,4);fKinematics(2,4);fKinematics(3,4);0;0;val;];
    dt = pinv(jac) * dx;
    
    % Update the values
    theta1 = theta1+dt(1);
    theta2 = theta2+dt(2); 
    d3 = d3+dt(3);  
    theta4 = theta4+dt(4);
    
    % Recalculate the kinematics
    fKinematics = forwardKinematics(a1,a2,theta1,theta2,d3,theta4);
    rotationOfForwardKinematics = fKinematics(1:3,1:3);
    val = round(atan2(rotationOfForwardKinematics(2,1),rotationOfForwardKinematics(1,1)),4);
    jac = jacobian(a1,a2,theta1,theta2,d3);
end
% Return the final values
theta1d = theta1;
theta2d = theta2;
d3d = d3; 
theta4d = theta4;