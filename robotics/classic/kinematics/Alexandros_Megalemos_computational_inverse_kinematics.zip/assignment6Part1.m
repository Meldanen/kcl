a1=1.5;
a2=1;
initialD3=0;
sign = -1; %Used to decide which solution we'll use

steps = 10;
theta1 = zeros(1,steps);
theta2 = zeros(1,steps);
theta4 = zeros(1,steps);
d3 = zeros(1,steps);
i=1;
hold on;
for t = 0:0.1:steps
    x = 1.5-t/20;
    y = t/10;
    z = -2+cos(pi*t/10);
    f = -pi/2-pi*t/20;
    [theta1(i),theta2(i),d3(i),theta4(i)] = angles(x, y, z, f, a1, a2, initialD3, sign);
    fKinematics = forwardKinematics(a1,a2,theta1(i),theta2(i),d3(i),theta4(i));
    rotationOfFKinematics = fKinematics(1:3,1:3);
    a = atan2(rotationOfFKinematics(2,1),rotationOfFKinematics(1,1));
    i = i + 1; %used for index
end

plotMovement(theta1, theta2, d3, theta4, steps)
