a1=1.5;
a2=1;
initialTheta1=0;
initialTheta2=0;
initialD3=0;
initialTheta4=0;
sign = 1; % Used to indicate which of the two solutions we're using

steps = 10;
theta1 = zeros(1,steps);
theta2 = zeros(1,steps);
theta4 = zeros(1,steps);
d3 = zeros(1,steps);
f = zeros(1,steps);
i=1;
hold on;
for t = 0:0.1:steps
    x = 1.5-t/20;
    y = t/10;
    z = -2+cos(pi*t/10);
    f(i) = -pi/2-pi*t/20;
    [theta1(i),theta2(i),d3(i),theta4(i)] = inverseKinematics(x, y, z, f(i), a1, a2, initialTheta1, initialTheta2, initialD3, initialTheta4);
    i = i+1;
end

plotMovement(theta1,theta2,d3,theta4, steps);