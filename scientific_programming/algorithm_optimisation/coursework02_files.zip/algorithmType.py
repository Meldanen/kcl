from enum import Enum


class AlgorithmType(Enum):
    BRUTE_FORCE = "Brute Force"
    DYNAMIC = "Dynamic"
